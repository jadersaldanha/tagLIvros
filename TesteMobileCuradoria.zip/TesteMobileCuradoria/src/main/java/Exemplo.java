import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServerHasNotBeenStartedLocallyException;

public class Exemplo {
	  	private AndroidDriver<MobileElement> driver;
	    private final String SEARCH_ACTIVITY = "br.com.taglivros.ui.MainActivity";
	    private final String ALERT_DIALOG_ACTIVITY = ".app.AlertDialogSamples";
	    private final String PACKAGE = "br.com.taglivros.taglivros";
	    private static AppiumDriverLocalService service;

	    @Before
	    public void setUp() throws IOException {
	    	service = AppiumDriverLocalService.buildDefaultService();
	        service.start();

	        if (service == null || !service.isRunning()) {
	        	throw new AppiumServerHasNotBeenStartedLocallyException(
	        			"An appium server node is not started!");
	        }	          
	         
	        File classpathRoot = new File(System.getProperty("user.dir"));
	        File appDir = new File(classpathRoot, "C:\\Users\\Tag Livros\\Downloads");
	        File app = new File(appDir.getCanonicalPath(), "app-curadoria-release.apk");
	        DesiredCapabilities capabilities = new DesiredCapabilities();
	        capabilities.setCapability("deviceName","Android Emulator");
	        capabilities.setCapability("app", app.getAbsolutePath());
	        capabilities.setCapability("appPackage", "br.com.taglivros.taglivros");
	        capabilities.setCapability("appActivity", "br.com.taglivros.ui.MainActivity");
	        driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	        //driver = new AndroidDriver<>(service.getUrl(), capabilities);
	    }

	    @After
	    public void tearDown() {
	        driver.quit();
	    }


	    @Test()
	    public void testSendKeys() {
	        driver.startActivity(new Activity(PACKAGE, SEARCH_ACTIVITY));
	        AndroidElement searchBoxEl = (AndroidElement) driver.findElementById("br.com.taglivros.taglivros:id/email_edit_text");
	        searchBoxEl.sendKeys("Hello world!");
	        //AndroidElement onSearchRequestedBtn = (AndroidElement) driver.findElementById("btn_start_search");
	        //onSearchRequestedBtn.click();
	        //AndroidElement searchText = (AndroidElement) new WebDriverWait(driver, 30)
	          //      .until(ExpectedConditions.visibilityOfElementLocated(By.id("android:id/search_src_text")));
	        //String searchTextValue = searchText.getText();
	        //Assert.assertEquals(searchTextValue, "Hello world!");
	    }

//	    @Test
//	    public void testOpensAlert() {
//	        // Open the "Alert Dialog" activity of the android app
//	        driver.startActivity(new Activity(PACKAGE, ALERT_DIALOG_ACTIVITY));
//
//	        // Click button that opens a dialog
//	        AndroidElement openDialogButton = (AndroidElement) driver.findElementById("io.appium.android.apis:id/two_buttons");
//	        openDialogButton.click();
//
//	        // Check that the dialog is there
//	        AndroidElement alertElement = (AndroidElement) driver.findElementById("android:id/alertTitle");
//	        String alertText = alertElement.getText();
//	        Assert.assertEquals(alertText, "Lorem ipsum dolor sit aie consectetur adipiscing\nPlloaso mako nuto siwuf cakso dodtos anr koop.");
//	        AndroidElement closeDialogButton = (AndroidElement) driver.findElementById("android:id/button1");
//
//	        // Close the dialog
//	        closeDialogButton.click();
//	    }

}
