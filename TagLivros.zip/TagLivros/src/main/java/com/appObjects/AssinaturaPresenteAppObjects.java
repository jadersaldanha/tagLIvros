package com.appObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AssinaturaPresenteAppObjects {
	
	private WebDriver driver; 
	
	public AssinaturaPresenteAppObjects (WebDriver driver) {
		this.driver = driver;		
	}

	public WebElement getPresentearButton () {
		return driver.findElement(By.xpath("/html/body/div[2]/section[1]/div/a/span"));
	}
	
	public WebElement getPeriodo1mes () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section[1]/ul/li[1]"));
	}
	
	public WebElement getPeriodo3mes () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section[1]/ul/li[2]"));
	}
	
	public WebElement getPeriodo6mes () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section[1]/ul/li[3]"));
	}
	
	public WebElement getPeriodo12mes () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section[1]/ul/li[4]"));
	}
	
	public WebElement getQueroTagCuradoriaButton () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section[2]/div/div[1]/div/div[2]/button"));
	}
	
	public WebElement getPresenteButton () {
		return driver.findElement(By.xpath("//*[@id=\"top\"]/div/nav/div[1]/div/div[5]/a"));
	}
	
	public WebElement getCaixinhaButton () {
		return driver.findElement(By.xpath("//*[@id=\"portal\"]/div/main/section/div/section/div[1]/ul/li[2]"));
	}
	
	public WebElement getNomePresenteadoTextField () {
		return driver.findElement(By.xpath("//*[@id=\"nome\"]"));
	}
	
	public WebElement getDeTextField () {
		return driver.findElement(By.id("de"));
	}
	
	public WebElement getParaTextField () {
		return driver.findElement(By.id("de"));
	}
	
	public WebElement getNomeCompletoTextField () {
		return driver.findElement(By.xpath("//*[@id=\"nome\"]"));
	}

	public WebElement getEmailTextField () {
		return driver.findElement(By.id("email"));
	}
	
	public WebElement getCpfTextField () {
		return driver.findElement(By.id("cpf"));
	}
	
	public WebElement getProximoButton () {
		return driver.findElement(By.className("sc-bdVaJa ksSRNm"));
	}
	
	//sc-bdVaJa ksSRNm
}
