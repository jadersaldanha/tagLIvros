package com.testCases;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.appObjects.CheckoutAppObjects;
import com.aventstack.extentreports.Status;
import com.support.Config;
import com.support.CsvDatapool;
import com.support.Drivers;
import com.support.Generator;
import com.support.IDatapool;
import com.support.Report;
import com.support.Screenshot;
import com.tasks.CheckoutTasks;
import com.verificationPoints.ValidarCamposdeDadosVerificationPoint;

public class CheckoutCuradoriaEmailSemArrobaTestCase {
	private static final String SYSTEM_URL = Config.get("environment.taglivros.homolog");
	private static final String DATAPOOL = Config.get("datapoolEmailJaUtilizado.pasta");
	private static final String IMAGEPATH = Config.get("screenshot.pasta");
	
	private WebDriver driver;
	private CheckoutTasks checkout; 
	private CheckoutAppObjects appObjects;
	private IDatapool datapool;
	private ValidarCamposdeDadosVerificationPoint validar;

	@Before
	public void setUp() {
		Report.startTest("Processo de Checkout Curadoria - Clube TagLivros");
		
		this.driver = Drivers.getChromeDriver();
		this.driver.get(SYSTEM_URL);
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		this.checkout = new CheckoutTasks(driver);
		this.appObjects = new CheckoutAppObjects (driver);
		datapool = new CsvDatapool(DATAPOOL);
		validar = new ValidarCamposdeDadosVerificationPoint(driver);
	}
	
	@Test
	public void testMain() throws InterruptedException {
		this.checkout.clicarQueroCuradoria();
		
		if (datapool.getValue("planomensal").equals("planomensal")) {
			this.checkout.planoMensal();
		}
		else {
			this.checkout.planoAnual();
		}
		
		datapool.reset();
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		while(datapool.hasNext()) {
			String screenshotArquivo1 = IMAGEPATH + Generator.dataHoraParaArquivo() + ".png";
			this.checkout.digitarEmail("saldanha.com.br");
			Screenshot.Tirar(driver, screenshotArquivo1);
			Report.log(Status.PASS, "Digitou e-mail", screenshotArquivo1);

			String screenshotArquivo2 = IMAGEPATH + Generator.dataHoraParaArquivo() + ".png";
			this.checkout.digitarNome(datapool.getValue("nome"));
			Screenshot.Tirar(driver, screenshotArquivo2);
			Report.log(Status.PASS, "Digitou nome", screenshotArquivo2);
		
			validar.validarMensagemErroEmailSemArroba("E-mail inválido");	
			datapool.next();
		}
		
	}
	
	@After
	public void tearDown() {
		Report.close();
		this.driver.quit();
	}
}
