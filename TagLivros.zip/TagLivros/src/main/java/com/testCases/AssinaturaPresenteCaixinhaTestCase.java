package com.testCases;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import com.appObjects.CheckoutAppObjects;
import com.support.Config;
import com.support.CsvDatapool;
import com.support.Drivers;
import com.support.IDatapool;
import com.support.Report;
import com.tasks.AssinaturaPresenteTasks;
import com.tasks.CheckoutTasks;
import com.verificationPoints.ValidarCamposdeDadosVerificationPoint;

public class AssinaturaPresenteCaixinhaTestCase {
	private static final String SYSTEM_URL = Config.get("environment.taglivros.homolog");
	private static final String DATAPOOL = Config.get("datapoolEmailJaUtilizado.pasta");
	private static final String IMAGEPATH = Config.get("screenshot.pasta");
	
	private WebDriver driver;
	private CheckoutTasks checkout; 
	private CheckoutAppObjects appObjects;
	private AssinaturaPresenteTasks assinaturapresente;
	private IDatapool datapool;
	private ValidarCamposdeDadosVerificationPoint validar;

	@Before
	public void setUp() {
		Report.startTest("Processo de Checkout Curadoria - Clube TagLivros");
		
		this.driver = Drivers.getChromeDriver();
		this.driver.get(SYSTEM_URL);
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		this.checkout = new CheckoutTasks(driver);
		this.appObjects = new CheckoutAppObjects (driver);
		assinaturapresente = new AssinaturaPresenteTasks (driver);
		datapool = new CsvDatapool(DATAPOOL);
		validar = new ValidarCamposdeDadosVerificationPoint(driver);
	}
	
	@Test
	public void testMain() throws InterruptedException {
		assinaturapresente.clicarPresente();
		assinaturapresente.clicarPresentear();	
		//assinaturapresente.clicarPeriodo1Mes();
		//assinaturapresente.clicarPeriodo3Meses();
		//assinaturapresente.clicarPeriodo6Meses();
		assinaturapresente.clicarPeriodo12Meses();
		assinaturapresente.queroTagCuradoria();
		assinaturapresente.clicarCaixinha();
		assinaturapresente.digitarNomePresenteado("Jader");
		assinaturapresente.digitarDe("Teste");
		assinaturapresente.digitarPara("Teste2");
		assinaturapresente.digitarNomeCompleto("Teste1233");
		assinaturapresente.digitarEmail("teste@teste.com.br");
		assinaturapresente.digitarCpf("100.901.350-59");
		assinaturapresente.clicarProximo();
		
	}
	
	@After
	public void tearDown() {
		Report.close();
		//this.driver.quit();
	}

}
