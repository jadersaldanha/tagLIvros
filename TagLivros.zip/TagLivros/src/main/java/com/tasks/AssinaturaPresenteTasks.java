package com.tasks;

import org.openqa.selenium.WebDriver;
import com.appObjects.AssinaturaPresenteAppObjects;
import com.appObjects.CheckoutAppObjects;

public class AssinaturaPresenteTasks {
	
	private final AssinaturaPresenteAppObjects assinatura;
	private WebDriver driver;
	
	public AssinaturaPresenteTasks  (WebDriver driver) {
		this.driver = driver;
		this.assinatura = new AssinaturaPresenteAppObjects (this.driver);
	}
	
	public void clicarPresentear () {
		assinatura.getPresentearButton().click();	
	}
	
	public void clicarPeriodo1Mes () {
		assinatura.getPeriodo1mes().click();
	}
	
	public void clicarPeriodo3Meses () {
		assinatura.getPeriodo3mes().click();
	}
	
	public void clicarPeriodo6Meses () {
		assinatura.getPeriodo6mes().click();
	}
	
	public void clicarPeriodo12Meses () {
		assinatura.getPeriodo12mes().click();
	}
	
	public void queroTagCuradoria () {
		assinatura.getQueroTagCuradoriaButton().click();
	}

	public void clicarPresente () {
		assinatura.getPresenteButton().click();
	}
	
	public void clicarCaixinha () {
		assinatura.getCaixinhaButton().click();
	}
	
	public void digitarNomePresenteado (String presenteado) {
		assinatura.getNomePresenteadoTextField().sendKeys("Jader Saldanha");
	}
	
	public void digitarDe (String de) {
		assinatura.getDeTextField().sendKeys(de);
	}
	
	public void digitarPara (String para) {
		assinatura.getParaTextField().sendKeys(para);
	}
	
	public void digitarNomeCompleto (String nomecompleto) {
		assinatura.getNomeCompletoTextField().sendKeys(nomecompleto);
	}
	
	public void digitarEmail (String email) {
		assinatura.getEmailTextField().sendKeys(email);
	}
	
	public void digitarCpf (String cpf) {
		assinatura.getCpfTextField().sendKeys(cpf);
	}
	
	public void clicarProximo () {
		assinatura.getProximoButton().click();
	}
}
