package com.testCases;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.appium.Appium;
import com.aventstack.extentreports.Status;
import com.support.Config;
import com.support.CsvDatapool;
import com.support.Drivers;
import com.support.Generator;
import com.support.IDatapool;
import com.support.Report;
import com.support.Screenshot;

import io.appium.java_client.android.AndroidElement;


public class Teste {

	//private static final String SYSTEM_URL = Config.get("environment.taglivros.areausuario");
	//private static final String DATAPOOL = Config.get("datapool.pasta");
	//private static final String IMAGEPATH = Config.get("screenshot.pasta");
	private WebDriver driver;	
	private IDatapool datapool;
	private Appium appium;

	@Before
	public void setUp() {
		Report.startTest("Acesso a Area de Usuario");
		
//		this.driver = Drivers.getChromeDriver();
//		this.driver.get(SYSTEM_URL);
//		this.driver.manage().window().maximize();
//		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//datapool = new CsvDatapool(DATAPOOL);
		appium = new Appium ();
	}
	
	@Test
	public void testMain() throws InterruptedException {
		appium.startAndroid("Galaxy J6", "app-curadoria-release.apk");
	
	}
	
	@After
	public void tearDown() {
		Report.close();
		//this.driver.quit();
	}
}
