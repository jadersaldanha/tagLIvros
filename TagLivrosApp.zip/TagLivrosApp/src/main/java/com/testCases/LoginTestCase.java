package com.testCases;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.appium.Appium;
import com.support.IDatapool;
import com.support.Report;
import com.tasks.LoginTasks;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class LoginTestCase {

	// private static final String SYSTEM_URL =
	// Config.get("environment.taglivros.areausuario");
	// private static final String DATAPOOL = Config.get("datapool.pasta");
	// private static final String IMAGEPATH = Config.get("screenshot.pasta");
	AppiumDriver<AndroidElement> driver;
	
	private IDatapool datapool;
	private Appium appium;
	private LoginTasks login;

	@Before
	public void setUp() {
		Report.startTest("Acesso a Area de Usuario");

//			this.driver = Drivers.getChromeDriver();
//			this.driver.get(SYSTEM_URL);
//			this.driver.manage().window().maximize();
//			this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// datapool = new CsvDatapool(DATAPOOL);
		appium = new Appium();
		login = new LoginTasks(appium.startAndroid("deviceName", "apkFile"));
	}

	@Test
	public void testMain() throws InterruptedException {
		login.clicarQueroCuradoria();

	}

	@After
	public void tearDown() {
		Report.close();
		// this.driver.quit();
	}

}
