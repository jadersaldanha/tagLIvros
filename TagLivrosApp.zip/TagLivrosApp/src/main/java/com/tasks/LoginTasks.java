package com.tasks;

import org.openqa.selenium.WebDriver;
import com.appObjects.LoginAppObjects;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;

public class LoginTasks {
	
	private final LoginAppObjects checkout;
	private WebDriver driver;
	
	public LoginTasks (AppiumDriver<AndroidElement> driver) {
		this.driver = driver;
		this.checkout = new LoginAppObjects (driver); 
	}
	
	public void clicarQueroCuradoria () {
		this.checkout.emailTextField().sendKeys("jay");	
	}

}
