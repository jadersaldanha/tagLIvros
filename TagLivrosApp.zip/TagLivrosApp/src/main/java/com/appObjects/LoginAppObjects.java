package com.appObjects;

import com.appium.Appium;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;

public class LoginAppObjects {
	
	private AppiumDriver<AndroidElement> driver;
	
	public LoginAppObjects (AppiumDriver<AndroidElement> driver) {
		this.driver = driver;		
	}	
	
	public AndroidElement emailTextField () {
		return driver.findElementById("br.com.taglivros.taglivros:id/email_edit_text");
	}
	


}
