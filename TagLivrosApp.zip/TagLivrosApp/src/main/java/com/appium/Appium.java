package com.appium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.DesiredCapabilities;
import com.github.genium_framework.appium.support.server.AppiumServer;
import com.github.genium_framework.server.ServerArguments;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class Appium {

	private static AppiumServer server;
	private static final String SERVER_URL = "http://127.0.0.1:4723/wd/hub";

	public static AppiumDriver<AndroidElement> startAndroid(String deviceName, String apkFile) {
		try {
			//initGenymotionServer(deviceName);
			initAppiumServer();

			String appFilePath = getApkFilePath(apkFile);
			URL serverUrl = new URL(SERVER_URL);

			AppiumDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(serverUrl,
					configCapabilities(deviceName, "C:\\Users\\Tag Livros\\Downloads\\app-curadoria-release.apk"));
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

//			AndroidElement searchBoxEl = (AndroidElement) driver.findElementById("br.com.taglivros.taglivros:id/email_edit_text");
//			searchBoxEl.sendKeys("priscila.koboldt@taglivros.com.br");
//			AndroidElement searchBoxE2 = (AndroidElement) driver
//					.findElementById("br.com.taglivros.taglivros:id/password_edit_text");
//			searchBoxE2.sendKeys("taglivros2017");
//
//			AndroidElement searchBoxE3 = (AndroidElement) driver
//					.findElementById("br.com.taglivros.taglivros:id/login_button");
//			searchBoxE3.click();
//
//			AndroidElement searchBoxE4 = (AndroidElement) driver
//					.findElementById("br.com.taglivros.taglivros:id/begin_button");
//			searchBoxE4.click();
//
//			AndroidElement searchBoxE5 = (AndroidElement) driver
//					.findElementById("br.com.taglivros.taglivros:id/skip_button");
//			searchBoxE5.click();

			// br.com.taglivros.taglivros:id/text_new_post

			// br.com.taglivros.taglivros:id/post_edit_text

			// br.com.taglivros.taglivros:id/spoiler_yes_check_box

			// br.com.taglivros.taglivros:id/spoiler_no_check_box

			// br.com.taglivros.taglivros:id/camera_button

			// br.com.taglivros.taglivros:id/action_close

			// br.com.taglivros.taglivros:id/action_submit

			//// android.support.v7.app.ActionBar.Tab[@content-desc="CAFEZINHO"]/android.widget.TextView
			//// //cafezinhobutton

			//// android.support.v7.app.ActionBar.Tab[@content-desc="ESTANTE"]/android.widget.TextView
			//// //estante button

			// //android.support.v7.app.ActionBar.Tab[@content-desc="GALERIA"]/android.widget.TextView
			// //galeria button

			// /hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[5]/android.widget.ImageView
			// //perfil

			// /hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[4]/android.widget.ImageView
			// //notifica��es

			// /hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[3]/android.widget.ImageView

			// /hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.ImageView
			// //encontros

			// /hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[1]/android.widget.ImageView
			// //home

			// br.com.taglivros.taglivros:id/iv_add_meeting //novo encontro

			// br.com.taglivros.taglivros:id/cet_meeting_title // titulo novo encontro

			// br.com.taglivros.taglivros:id/cet_meeting_place //local

			// br.com.taglivros.taglivros:id/cet_meeting_city //cidade

			// br.com.taglivros.taglivros:id/cet_meeting_date //data evento

			// br.com.taglivros.taglivros:id/cet_meeting_time //horario

			// br.com.taglivros.taglivros:id/cet_meeting_description //descricao evento

			// br.com.taglivros.taglivros:id/ctv_change_state //trocar

			// br.com.taglivros.taglivros:id/button_chat //novo chat

			// br.com.taglivros.taglivros:id/edit //

			// br.com.taglivros.taglivros:id/button_send //enviar mensagem chat

			// //android.widget.ImageButton[@content-desc="Navegar para cima"] //botao
			// voltar

			// br.com.taglivros.taglivros:id/button_camera // botao enviar foto

			// br.com.taglivros.taglivros:id/button_image // enviar imagem

			// br.com.taglivros.taglivros:id/input // campo de digitar mensagem

			// br.com.taglivros.taglivros:id/action_button //editar perfil

			// br.com.taglivros.taglivros:id/toolbar_save //salvar

			// br.com.taglivros.taglivros:id/toolbar_edit_settings //configura��es

			// br.com.taglivros.taglivros:id/btn_gallery_adapter //galeria

			// br.com.taglivros.taglivros:id/btn_book_adapter // livros

			// br.com.taglivros.taglivros:id/toolbar_search // buscar

			return driver;
		} catch (MalformedURLException ex) {
			System.out.println("Invalid server URL: " + ex.getMessage());
			throw new RuntimeException(ex);
		}
	}

	public static void waitForLoading() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException ex) {
			System.out.println("WaitForLoading failure: " + ex.getMessage());
		}
	}

	public static void stop(AppiumDriver<AndroidElement> driver) {
		driver.quit();
		server.stopServer();
	}

//	    public static void stopGenymotionServer() {
//	        Genymotion.stopGenymotion();
//	    }

//	private static void initGenymotionServer(String deviceName) {
//		Genymotion.startGenymotion("deviceName");
//	}

	private static void initAppiumServer() {
		ServerArguments arguments = new ServerArguments();
		arguments.setArgument("--address", "127.0.0.1");
		arguments.setArgument("--port", "4723");
		arguments.setArgument("--no-reset", true);

		server = new AppiumServer(arguments);

		System.out.println("Situa��o do Appium Server: " + server.isServerRunning());

		server.startServer();

		System.out.println("Situa��o do Appium Server: " + server.isServerRunning());

		if (server.isServerRunning()) {
			System.out.println("Appium executando em 127.0.0.1 porta 4723!");
		} else {
			System.out.println("Appium n�o inicializado.");
		}
	}

	private static DesiredCapabilities configCapabilities(String deviceName, String appFilePath) {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "8.0.0");
		capabilities.setCapability("deviceName", "Galaxy J6");
		capabilities.setCapability("app", "C:\\Users\\Tag Livros\\Downloads\\app-curadoria-release.apk");
		capabilities.setCapability("appPackage", "br.com.taglivros.taglivros");
		capabilities.setCapability("appActivity", "br.com.taglivros.ui.MainActivity");

		return capabilities;
	}

	private static String getApkFilePath(String apkFile) {
		File classpathRoot = new File(System.getProperty("user.dir"));
		File appDir = new File(classpathRoot, "/apps/");
		File apk = new File(appDir, apkFile);
		return apk.getAbsolutePath();
	}

}
